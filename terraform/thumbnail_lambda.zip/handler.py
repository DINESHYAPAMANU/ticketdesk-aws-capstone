import json
import urllib.parse
import boto3

s3 = boto3.client('s3')

def lambda_handler(event, context):
    print("S3 Event Received: " + json.dumps(event))
    for record in event.get('Records', []):
        bucket = record['s3']['bucket']['name']
        key = urllib.parse.unquote_plus(record['s3']['object']['key'], encoding='utf-8')
        print(f"Processing object {key} from bucket {bucket}")
        
        # Write processed metadata thumbnail reference back to thumbnails/ prefix
        thumbnail_key = key.replace("uploads/", "thumbnails/") + ".thumb.json"
        metadata_payload = json.dumps({
            "status": "processed",
            "original_key": key,
            "bucket": bucket,
            "message": "Thumbnail metadata generated successfully by S3 event trigger"
        })
        
        s3.put_object(
            Bucket=bucket,
            Key=thumbnail_key,
            Body=metadata_payload,
            ContentType="application/json"
        )
        print(f"Created thumbnail metadata at {thumbnail_key}")
    return {"statusCode": 200, "body": "Thumbnail generation completed."}
